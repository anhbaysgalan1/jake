# integration
NOTE: make changes in fixtures files (./fixtures) before testing
